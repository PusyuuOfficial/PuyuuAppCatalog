/*****************************************
  *----------------------------------
  |  ThisJsVersion: 1.19.4        |
  |  © 2021-2024 By PusyuuWanko/  |
  |  LastUpdate: 2024-02-11       |
  |  License: none                |
  |  PusyuuMultiApp               |
----------------------------------*
******************************************/

/* PusyuuOfMesseage
---------------------------------*/

const pusyuu = "あ、あ、テステス、テストコメントです。まだまだプログラミング初心者です。応戦よろしくお願いします。";
  console.log(pusyuu);

/* OnClickMusic
---------------------------------*/

window.onload = function() {
  const audioFiles = [
    { id: 'audioBtn1', src: '../MusicData/hage.mp3' },
    { id: 'audioBtn2', src: '../MusicData/another_audio.mp3' },
    { id: 'audioBtn3', src: '../MusicData/yet_another_audio.mp3' }
  ];

  let currentAudio = null;

  function playAudio(audioSrc) {
    const audio = new Audio(audioSrc);
    audio.play();
    return audio;
  }

  function getAudioSrcById(id) {
    const audioData = audioFiles.find(item => item.id === id);
    return audioData ? audioData.src : null;
  }

  // クリックイベントを追加
  audioFiles.forEach(audioData => {
    const button = document.getElementById(audioData.id);
    if (button) {
      button.onclick = function() {
        if (currentAudio && !currentAudio.paused) {
          currentAudio.pause();
          currentAudio.currentTime = 0;
        }

        const audioSrc = getAudioSrcById(audioData.id);
        if (audioSrc) {
          currentAudio = playAudio(audioSrc);
        }
      };
    }
  });
};

/* LoadingDisplay
---------------------------------*/

window.onload = function() {
  let spinner = document.getElementById('loading');
  // 条件文で要素が存在しない場合に処理をスキップ
  if (!spinner) {
    console.log(`Element with ID "loading" not found.`);
    return;
  }
  spinner.classList.add('loaded');
}

/* CreateToolTheFaceMoJi 
---------------------------------*/

// 入力フィールドのIDのリスト
const inputFieldIds = ["lefthand", "outline", "lefteyes", "nose", "righteyes", "righthand", "comment"];

// 入力フィールドの要素を格納するオブジェクト
const inputFields = {};

// 各入力フィールドの要素を取得し、イベントリスナーを設定
for (let i = 0; i < inputFieldIds.length; i++) {
  const inputFieldId = inputFieldIds[i];
  const inputField = document.getElementById(inputFieldId);

  // 条件文で要素が存在しない場合に処理をスキップ
  if (!inputField) {
    console.log(`Element with ID "${inputFieldId}" not found.`);
    continue;
  }

  inputFields[inputFieldId] = inputField;
  inputFields[inputFieldId].addEventListener("input", updateFace);
}

// スペースのチェックボックスを取得
const spaceCheckbox = document.getElementById("space");

// 条件文で要素が存在しない場合に処理をスキップ
if (!spaceCheckbox) {
  console.log(`Element with ID "space" not found.`);
} else {
  spaceCheckbox.addEventListener("change", updateFace);
}

// 顔を生成する関数
function createFace() {
  const lefthand = inputFields["lefthand"].value;
  const outline = inputFields["outline"].value;
  const lefteyes = inputFields["lefteyes"].value;
  const nose = inputFields["nose"].value;
  const righteyes = inputFields["righteyes"].value;
  const righthand = inputFields["righthand"].value;
  const space = spaceCheckbox.checked ? " " : "";
  const comment = inputFields["comment"].value;

  const face = lefthand + outline.substring(0, 1) + lefteyes + nose + righteyes + outline.substring(1) + righthand + space + comment;
  document.getElementById("faceContainer").innerHTML = face;
}

// 入力フィールドが変更されたときに顔を生成する関数を呼び出す
function updateFace() {
  createFace();
}

/* FremworkForMemoryOfMemo
---------------------------------*/

function save() {
  let MemoData = document.MemoForm.Memo.value;
  // テキストファイルを作成
  const blob = new Blob([MemoData], {
    type: 'text/plain'
  });
  const url = URL.createObjectURL(blob);
  // ダウンロード用のリンクを作成
  const downloadLink = document.createElement('a');
  downloadLink.href = url;
  downloadLink.download = 'P-memo.txt'; // ダウンロード時のファイル名を指定
  downloadLink.click();
}

function loadFile(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function (event) {
    const MemoData = event.target.result;
    document.MemoForm.Memo.value = MemoData;
  };
  reader.readAsText(file);
}

function load() {
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = 'text/plain'; // テキストファイルのみを選択可能にする
  fileInput.addEventListener('change', loadFile);
  fileInput.click();
}

/* select kabegami
---------------------------------*/

document.addEventListener('DOMContentLoaded', function() {
  const select = document.getElementById('background-select');
  const uploadInput = document.getElementById('upload-input');
  if (select && uploadInput) {
    const body = document.body;
    const maxFileSize = 1 * 1024 * 1024; // 1MB in bytes
    const selectedImage = localStorage.getItem('PusyuuMultiApp_selectedImage');
    if (selectedImage) {
      body.style.backgroundImage = `url(${selectedImage})`;
      select.value = selectedImage;
    }

    select.addEventListener('change', function() {
      const selectedImage = select.value;
      body.style.backgroundImage = `url(${selectedImage})`;
      localStorage.setItem('PusyuuMultiApp_selectedImage', selectedImage); // Changed the key to 'PusyuuMultiApp_selectedImage'
    });

    uploadInput.addEventListener('change', function(event) {
      const file = event.target.files[0];
      const reader = new FileReader();

      if (file.size > maxFileSize) {
        alert('The file size exceeds the maximum limit of 1MB.');
        return;
      }

      reader.onload = function() {
        const uploadedImage = reader.result;
        const randomThreeDigitNumber = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        const imageName = 'Your wallpaper' + randomThreeDigitNumber;
        localStorage.setItem(imageName, uploadedImage);
        addImageOption(imageName, uploadedImage);
      };
      reader.readAsDataURL(file);
    });

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key.startsWith('Your wallpaper')) {
        const uploadedImage = localStorage.getItem(key);
        addImageOption(key, uploadedImage);
      }
    }

    function addImageOption(imageName, uploadedImage) {
      const option = document.createElement('option');
      option.value = uploadedImage;
      option.text = imageName;
      select.add(option);

      if (uploadedImage === selectedImage) {
        option.selected = true;
      }
    }

    function applyBackgroundStyles() {
      body.style.backgroundSize = 'cover';
      body.style.backgroundRepeat = 'no-repeat';
      body.style.backgroundPosition = 'center';
      body.style.backgroundAttachment = 'fixed';
    }
  
    applyBackgroundStyles();

    function addPreloadedImages() {
      const preloadedImages = [
        './SystemFolder/ImageData/sys_wallpaper/1.JPG',
        './SystemFolder/ImageData/sys_wallpaper/2.jpg',
        './SystemFolder/ImageData/sys_wallpaper/4.jpg',
        './SystemFolder/ImageData/sys_wallpaper/5.jpg',
        './SystemFolder/ImageData/sys_wallpaper/7.JPG'
      ];
      addImageOption("Select Wallpaper", "");
      preloadedImages.forEach(function(image, index) {
        const wallpaperNumber = (index + 1).toString();
        const imageName = 'wallpaper ' + wallpaperNumber;
        addImageOption(imageName, image);
      });
    }

    addPreloadedImages();
  } else {
    console.log('Element with ID "background-select" and "upload-input" not found.');
  }
});

/* Nav List
---------------------------------*/

document.addEventListener('DOMContentLoaded', function () {

  let applist = [
    {
      image: "./SystemFolder/IconData/img-23.png",
      title: "プシュー掲示板",
      link: "#modal-1",
      lktitle: "プシュー掲示板",
    },
    {
      image: "./SystemFolder/IconData/img-24.png",
      title: "天気予報",
      link: "#modal-2",
      lktitle: "天気予報",
    },
    {
      image: "./SystemFolder/IconData/img-25.png",
      title: "地震速報",
      link: "#modal-3",
      lktitle: "地震速報",
    },
    {
      image: "./SystemFolder/IconData/img-4.png",
      title: "オセロゲーム",
      link: "#modal-4",
      lktitle: "PUSYUU NEWS",
    },
    {
      image: "./SystemFolder/IconData/img-26.png",
      title: "メモ帳",
      link: "#modal-5",
      lktitle: "メモ帳",
    },
    {
      image: "./SystemFolder/IconData/img-27.png",
      title: "チャイム付き時計、カレンダー",
      link: "#modal-6",
      lktitle: "チャイム付き時計、カレンダー",
    },
    {
      image: "./SystemFolder/IconData/img-17.png",
      title: "ミュージックステーション",
      link: "#modal-7",
      lktitle: "ミュージックステーション",
    },
    {
      image: "./SystemFolder/IconData/img-28.png",
      title: "設定",
      link: "#modal-8",
      lktitle: "設定",
    },
    {
      image: "./SystemFolder/IconData/img-29.png",
      title: "顔文字作成機",
      link: "#modal-9",
      lktitle: "顔文字作成機",
    },
    {
      image: "./SystemFolder/IconData/img-30.png",
      title: "ヘルプ",
      link: "#modal-10",
      lktitle: "ヘルプ",
    },
    {
      image: "./SystemFolder/IconData/img-0.png",
      title: "カラーコードマッチャーベータ版",
      link: "#modal-11",
      lktitle: "カラーコードマッチャーベータ版",
    },
    {
      image: "./SystemFolder/IconData/img-31.png",
      title: "周期表",
      link: "#modal-12",
      lktitle: "周期表",
    },
    {
      image: "./SystemFolder/IconData/img-32.png",
      title: "検索",
      link: "#modal-13",
      lktitle: "検索CocCoc検索エンジンを使用した検索アプリ的なもの",
    },
  ];

  function createAppItem(app, modalWrapper) {
    let appItem = document.createElement("div");
    appItem.className = "draggable-item";
    appItem.setAttribute("data-id", app.link);
    let aLink = document.createElement("a");
    aLink.className = "app_link";
    aLink.href = app.link;
    aLink.title = app.lktitle;
    let appWrapper = document.createElement("div");
    appWrapper.className = "app_wrapper";
    let appImage = document.createElement("div");
    appImage.className = "app_box-1";
    let img = document.createElement("img");
    img.src = app.image;
    img.alt = "image of app";
    img.className = "img-rs_saidai";
    img.oncontextmenu = function () {
      return false;
    };
    img.onselectstart = function () {
      return false;
    };
    img.onmousedown = function () {
      return false;
    };
    img.border = "0";
    let appName = document.createElement("p");
    appName.className = "app_name";
    appName.textContent = app.title;
    appImage.appendChild(img);
    appWrapper.appendChild(appImage);
    appWrapper.appendChild(appName);
    aLink.appendChild(appWrapper);
    appItem.appendChild(aLink);
    return appItem;
  }

  let modalContents = [
    {
      id: "modal-1",
      title: "プシュー掲示板",
      description: "ここでは、いわゆる掲示板投稿が可能です。",
      src: "https://21emon.wjg.jp/bbs_of_php"
    },
    {
      id: "modal-2",
      title: "天気予報",
      description: "ここでは、自動的に現在地の天気を取得し表示できます。",
      src: "./SystemFolder/AppData/TenkiApiOfTool/index.html"
    },
    {
      id: "modal-3",
      title: "地震速報",
      description: "ここでは、地震速報とランダムなわんこの画像表示できます。",
      src: "./SystemFolder/AppData/ZisinnApiOfTool/index.html"
    },
    {
      id: "modal-4",
      title: "オセロゲーム",
      description: "オセロ大戦ができます。少々デザイン変更しました。",
      src: "./SystemFolder/AppData/OseroJS/osero.html"
    },
    {
      id: "modal-5",
      title: "メモ帳",
      description: "メモの記録ができます。",
      src: "./SystemFolder/AppData/MemoNote/index.html"
    },
    {
      id: "modal-6",
      title: "チャイム付き時計、カレンダー",
      description: "時計とカレンダーをひと目で確認できます",
      src: "./SystemFolder/AppData/ClockWithTimeSignal/index.html"
    },
    {
      id: "modal-7",
      title: "ミュージックステーション",
      description: "ラジオミュージックステーションを聞くことができます。",
      src: "./SystemFolder/AppData/VueMusicPlayer/music-player.html"
    },
    {
      id: "modal-8",
      title: "設定",
      description: "設定の反映にリロードが必要です。",
      src: "./SystemFolder/AppData/Settings/index.html"
    },
    {
      id: "modal-9",
      title: "顔文字作成機",
      description: "不器用な方でも簡単に日本の伝統てきな顔文字が作成できます。",
      src: "./SystemFolder/AppData/CreateToolTheFaceMoji/index.html"
    },
    {
      id: "modal-10",
      title: "ヘルプ",
      description: "ヘルプを見ることができます。",
      src: "./SystemFolder/AppData/Help/index.html"
    },
    {
      id: "modal-11",
      title: "カラーコードマッチャーベータ版",
      description: "検出した色を選択して、かざしてマッチさせたりできます。",
      src: "./SystemFolder/AppData/ColorCodeMatcher"
    },
    {
      id: "modal-12",
      title: "周期表",
      description: "そこそこかっこいい周期表を見ることができます。",
      src: "./SystemFolder/AppData//PeriodicTable"
    },
    {
      id: "modal-13",
      title: "CocCoc",
      description: "WindowsXPでのブラウザとしても使用可能な最強ブラウザのベトナム生まれの検索エンジン",
      src: "https://coccoc.com/search"
    },
  ];

  function createModalElement(modalData, modalWrapper, appId) {
    const modalDiv = document.createElement('div');
    modalDiv.className = "window";
    modalDiv.setAttribute("id", modalData.id);
    modalDiv.innerHTML = `
      <div>
        <a class="close"></a>
        <div>
          <div>
            <h2>${modalData.title}</h2>
            <p>${modalData.description}</p>
            <iframe title="アプリコンテンツ" frameborder="0" class="appframe-size" src="${modalData.src}"></iframe>
          </div>
        </div>
      </div>
    `;
    return modalDiv;
  }

  let appListWrapper = document.getElementById("app_list_wrapper");
  let modalWrapper = document.getElementById("modal_wrapper");

  if (appListWrapper || modalWrapper) {
    appListWrapper.innerHTML = "";

    function setupCloseWindowLogic(closeButton, modalElement) {
      closeButton.addEventListener('click', function() {
        const userConfirmation = confirm("バックグランドで実行？・閉じますか？");
        if (userConfirmation) {
          closeButton.href = "#mc";
          const modalId = window.location.hash.replace(/#/, '');
          let modalElement = document.getElementById(modalId);
          if (modalElement) {
            let parentEle = modalElement.parentElement;
            if (parentEle) {
              parentEle.removeChild(modalElement);
            }
          }
        } else {
          closeButton.href = "#mc";
        }
      });
    }

    function setupWindowLogic(clickedApp) {
      const modalData = modalContents.find((modal) => "#" + modal.id === clickedApp.link);
      if (modalData) {
        const existingModal = document.getElementById(clickedApp.link.substring(1));
        if (!existingModal) {
          const modalElement = createModalElement(modalData, modalWrapper, clickedApp.link);
          modalWrapper.appendChild(modalElement);

          const closeButton = modalElement.querySelector('.close');
          if (closeButton) {
            setupCloseWindowLogic(closeButton, modalElement);
          } else {
            setTimeout(() => setupCloseWindowLogic(closeButton, modalElement), 100);
          }
        }
      } else {
        console.error("モーダルデータが見つかりません");
      }
    }

    for (let i = 0; i < applist.length; i++) {
      let appItem = createAppItem(applist[i], modalWrapper);
      appListWrapper.appendChild(appItem);
      appItem.addEventListener('click', function () {
        const clickedApp = applist[i];
        setupWindowLogic(clickedApp);
      });
    }

    function updateModalPosition(appId) {
      const modalData = modalContents.find((modal) => "#" + modal.id === appId);
      const modalElement = createModalElement(modalData, modalWrapper, appId);
      const existingModal = document.getElementById(appId.substring(1));

      if (existingModal) {
        existingModal.innerHTML = createModalContent(modalData);
      } else {
        modalWrapper.appendChild(modalElement);
        modalElement.setAttribute('data-id', appId);
        const closeButton = modalElement.querySelector('.close');
        setupCloseWindowLogic(closeButton, modalElement);
      }
    }

    const draggableItems = document.querySelectorAll('.draggable-item');
    let draggedItem = null;
    const appOrderKey = 'PusyuuMultiApp';

    function dragStart(e) {
      draggedItem = this;
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/html', this.innerHTML);
    }

    function dragOver(e) {
      if (e.preventDefault) {
        e.preventDefault();
      }
      e.dataTransfer.dropEffect = 'move';
      return false;
    }

    function drop(e) {
      if (e.stopPropagation) {
        e.stopPropagation();
      }
      if (draggedItem !== this) {
        const draggedId = draggedItem.getAttribute('data-id');
        const droppedId = this.getAttribute('data-id');

        draggedItem.setAttribute('data-id', droppedId);
        this.setAttribute('data-id', draggedId);

        draggedItem.innerHTML = this.innerHTML;
        this.innerHTML = e.dataTransfer.getData('text/html');

        updateLocalStorageOrder();
        updateModalPosition(draggedItem.getAttribute('data-id'));
      }
      return false;
    }

    function updateLocalStorageOrder() {
      const appLinkElements = document.querySelectorAll('.draggable-item');
      const order = Array.from(appLinkElements).map(item => {
        const appId = item.getAttribute('data-id');
        const modalData = modalContents.find((modal) => "#" + modal.id === appId);
        return modalData ? item.outerHTML : null;
      }).filter(item => item !== null);
      localStorage.setItem(appOrderKey, JSON.stringify(order));
      
      applist = Array.from(appLinkElements).map(item => {
        const appId = item.getAttribute('data-id');
        return applist.find(app => app.link === appId);
      });
    }

    function addDragListeners() {
      const draggableItems = document.querySelectorAll('.draggable-item');
      draggableItems.forEach(item => {
        item.addEventListener('dragstart', dragStart);
        item.addEventListener('dragover', dragOver);
        item.addEventListener('drop', drop);
        item.addEventListener('click', function() {
          const clickedApp = applist.find(app => app.link === item.getAttribute('data-id'));
          setupWindowLogic(clickedApp);
        });
      });
    }

    function restoreOrderFromLocalStorage() {
      const appOrder = JSON.parse(localStorage.getItem(appOrderKey));
      if (appOrder) {
        const appContainer = document.querySelector('.yokoori');
        const appLinkElements = Array.from(appContainer.querySelectorAll('.draggable-item'));
        const updatedOrder = [];
        for (const item of appOrder) {
          const matchingElement = appLinkElements.find(element => element.outerHTML === item);
          if (matchingElement) {
            updatedOrder.push(matchingElement.outerHTML);
          }
        }
        for (const element of appLinkElements) {
          if (!updatedOrder.includes(element.outerHTML)) {
            updatedOrder.push(element.outerHTML);
          }
        }
        while (updatedOrder.length > appLinkElements.length) {
          updatedOrder.pop();
        }
        while (updatedOrder.length > appLinkElements.length) {
          updatedOrder.push(appLinkElements[updatedOrder.length].outerHTML);
        }
        appContainer.innerHTML = updatedOrder.join('');
        addDragListeners();
      }
    }

    restoreOrderFromLocalStorage();
    addDragListeners();

  } else {
    console.log('Element with ID "app_list_wrapper" or "modal_wrapper" not found.');
  }
});

/* Pwa Settings
---------------------------------*/

window.onload = function() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register("./SystemFolder/JsData/sw.js")
    .then((reg) => {
      console.log("PWA:", reg)
    })
    .catch((error) => {
      console.error("PWA:", error);
    });
  }
}

/* Right Click Disable
---------------------------------*/

document.addEventListener('DOMContentLoaded', function() {
  var targetElement = document.getElementById('target-element');
  var customMenu = document.getElementById('custom-menu');

  // 要素で右クリックイベントを検出
  if (targetElement || customMenu) {
    targetElement.addEventListener('contextmenu', function(event) {
      event.preventDefault(); // デフォルトの右クリックメニューを無効化
      customMenu.style.left = event.clientX + 'px';
      customMenu.style.top = event.clientY + 'px';
      customMenu.style.display = 'block';
    });

    // クリック外領域でカスタムメニューを非表示に
    document.addEventListener('click', function(event) {
      customMenu.style.display = 'none';
    });
  } else {
    console.log('Element with ID "targetElement" or "customMenu" not found.');
  }
});
