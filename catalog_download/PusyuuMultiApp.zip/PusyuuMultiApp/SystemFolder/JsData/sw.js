self.addEventListener("fetch", function(e) {
  console.log("Fetch event intercepted:", e.request);
});
