# Othello JS

A quick and dirty implementation of [Othello (Reversi)](http://en.wikipedia.org/wiki/Reversi).
[Try it online](http://kana.github.com/othello-js/).
