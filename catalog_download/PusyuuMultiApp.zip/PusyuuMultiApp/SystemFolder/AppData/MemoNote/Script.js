/*****************************************
  *----------------------------------
  |  ThisJsVersion: 2.3.2         |
  |  © 2021-2024 By PusyuuWanko/  |
  |  LastUpdate: 2024-01-19       |
  |  License: none                |
  |  SimpleMemoNote               |
----------------------------------*
******************************************/

function showCharsetModal() {
  document.getElementById('myModal').style.display = 'block';
}

function closeCharsetModal() {
  document.getElementById('myModal').style.display = 'none';
}

function save() {
  let MemoData = document.MemoForm.Memo.value;
  const sendSave = document.getElementById("sendSaveButton");
  const selectedCharset = document.getElementById('charsetSelect');
  
  showCharsetModal();

  sendSave.addEventListener("click", function() {
    if (selectedCharset.value !== "") {
      // Convert the MemoData to the selected character set
      const encoder = new TextEncoder();
      const decodedMemoData = encoder.encode(MemoData);
      const decodedText = new TextDecoder(selectedCharset.value).decode(decodedMemoData);

      // Create a Blob with the converted text
      const blob = new Blob([new TextEncoder().encode(decodedText)], {
        type: 'text/plain;charset=' + selectedCharset.value
      });
      
      // Create a download link
      const downloadLink = document.createElement('a');
      downloadLink.href = URL.createObjectURL(blob);
      
      // Create a timestamp for the file name
      function time() {
        const now = new Date();
        const year = now.getFullYear();
        const month = now.getMonth() + 1;
        const day = now.getDate();
        const hour = now.getHours();
        const min = now.getMinutes();
        const sec = now.getSeconds();
        function addZero(number) {
          return number < 10 ? `0${number}` : number;
        }
        const formattedTime = `_${addZero(year)}${addZero(month)}${addZero(day)}_${addZero(hour)}${addZero(min)}${addZero(sec)}`;
        return formattedTime;
      }

      // Set the download link attributes
      downloadLink.download = 'P-memo' + time() + '.txt';

      // Trigger the download
      downloadLink.click();
    } else {
      alert("キャラクターの選択は必須です。選択を行ってください。");
    }
  });
}

function loadFile(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function (event) {
    const MemoData = event.target.result;
    document.MemoForm.Memo.value = MemoData;
    
    updateMoziCount();
    saveTemporarily();
  };
  reader.readAsText(file);
}

function load() {
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = 'text/plain'; // テキストファイルのみを選択可能にする
  fileInput.addEventListener('change', loadFile);
  fileInput.click();
}

function moziUpper() {
  let text = document.MemoForm.Memo.value;
  text = text.toUpperCase();
  document.MemoForm.Memo.value = text;
}

function moziLower() {
  let text = document.MemoForm.Memo.value;
  text = text.toLowerCase();
  document.MemoForm.Memo.value = text;
}

function updateMoziCount() {
  const text = document.MemoForm.Memo;
  document.getElementById("moziCount").innerHTML = data = text.value.length + "Mozi";
}

function saveTemporarily() {
  let text = document.MemoForm.Memo.value;
  sessionStorage.setItem("Memo", text);
}

window.onload = function() {
  const text = document.MemoForm.Memo;
  text.addEventListener('input', ()=> {
    updateMoziCount();
    saveTemporarily();
  });
  updateMoziCount();
  let getMemoData = sessionStorage.getItem("Memo");
  if (getMemoData) {
    text.value = getMemoData;
    updateMoziCount();
  }
}
