/*****************************************
  *------------------------------------
  |  ThisStyleVersion: 2.3.0        |
  |  © 2021-2024 By PusyuuWanko/    |
  |  LastUpdate: 2024-01-17         |
  |  License: none                  |
  |  PusyuuZooomCommunicationToool  |
------------------------------------*
******************************************/

window.addEventListener("DOMContentLoaded", function() {
  const disp = document.getElementById("display");
  const fsize = document.getElementById("Fsize");
  fsize.addEventListener('input', () => {
    let fFsize = fsize.value + 'px';
    disp.style.fontSize = fFsize;
  });
  const data = document.getElementById("text");
  data.value = "";
  data.addEventListener('input', function() {
    disp.innerText = data.value;
  });
});
